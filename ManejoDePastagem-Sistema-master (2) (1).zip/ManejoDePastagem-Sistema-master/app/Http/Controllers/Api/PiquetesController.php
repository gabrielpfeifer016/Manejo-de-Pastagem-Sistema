<?php

namespace App\Http\Controllers\Api;

use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Api\BaseController as BaseController;

class PiquetesController extends BaseController
{
    /**
     * Piquetes
     */
        /**
         * Lista Piquetes
         */
        public function lista()
        {

        }

        /**
         * Criar Piquetes
         */
        public function novo(Request $request)
        {

        }

        /**
         * Apagar Piquetes
         */
        public function delete($id)
        {

        }
}
