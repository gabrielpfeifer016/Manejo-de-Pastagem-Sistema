<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PastosRepository.
 *
 * @package namespace App\Repositories;
 */
interface PastosRepository extends RepositoryInterface
{
    //
}
