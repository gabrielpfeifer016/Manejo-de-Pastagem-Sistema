<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface FazendasPiquetesRepository.
 *
 * @package namespace App\Repositories;
 */
interface FazendasPiquetesRepository extends RepositoryInterface
{
    //
}
