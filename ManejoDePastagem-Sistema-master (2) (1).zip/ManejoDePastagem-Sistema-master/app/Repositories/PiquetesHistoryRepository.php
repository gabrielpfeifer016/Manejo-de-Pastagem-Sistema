<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PiquetesHistoryRepository.
 *
 * @package namespace App\Repositories;
 */
interface PiquetesHistoryRepository extends RepositoryInterface
{
    //
}
