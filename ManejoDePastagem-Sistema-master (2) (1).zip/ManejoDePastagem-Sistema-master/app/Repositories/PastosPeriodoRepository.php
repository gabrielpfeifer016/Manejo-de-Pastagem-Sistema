<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PastosPeriodoRepository.
 *
 * @package namespace App\Repositories;
 */
interface PastosPeriodoRepository extends RepositoryInterface
{
    //
}
