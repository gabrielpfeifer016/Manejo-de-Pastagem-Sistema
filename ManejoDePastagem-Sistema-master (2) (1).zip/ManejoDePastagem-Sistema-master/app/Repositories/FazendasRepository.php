<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface FazendasRepository.
 *
 * @package namespace App\Repositories;
 */
interface FazendasRepository extends RepositoryInterface
{
    //
}
