<footer class="footer">
  <div class="container-fluid">
    {{-- <div class="copyright float-right">
      &copy;
      <a href="https://agildesenvolvimento.com" target="_blank">Ágil Devs</a>
      <script>
        document.write(new Date().getFullYear())
      </script>.
    </div> --}}
  </div>
</footer>